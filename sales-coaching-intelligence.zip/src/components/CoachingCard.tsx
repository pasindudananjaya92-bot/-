import React, { useState } from "react";
import { CoachingCardData } from "../types";
import { CheckCircle2, AlertTriangle, Trophy, Zap, Sparkles, Award } from "lucide-react";

interface CoachingCardProps {
  cardData: CoachingCardData;
}

export default function CoachingCard({ cardData }: CoachingCardProps) {
  const [checkedSteps, setCheckedSteps] = useState<Record<number, boolean>>({});

  if (!cardData) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center">
        <p className="text-sm font-medium text-slate-400">Feedback payload empty.</p>
      </div>
    );
  }

  const { salespersonName, overallScore, summary, strengths = [], missedOpportunities = [], actionPlan = [] } = cardData;

  // Derive score styling parameters
  const getScoreColor = (score: number) => {
    if (score >= 90) return { text: "text-emerald-600", stroke: "#10b981", bg: "bg-emerald-50", label: "Elite Performance" };
    if (score >= 80) return { text: "text-amber-600", stroke: "#f59e0b", bg: "bg-amber-50", label: "Strong Match" };
    return { text: "text-rose-600", stroke: "#f43f5e", bg: "bg-rose-50", label: "Coaching Opportunities" };
  };

  const scoreMeta = getScoreColor(overallScore);

  // SVG parameters for progress ring
  const radius = 52;
  const strokeWidth = 10;
  const normalizedRadius = radius - strokeWidth * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (overallScore / 100) * circumference;

  const toggleStep = (idx: number) => {
    setCheckedSteps((v) => ({ ...v, [idx]: !v[idx] }));
  };

  return (
    <div className="space-y-6">
      {/* Executive KPI overview & Scorecard */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          
          {/* Radial Score Gauge */}
          <div className="col-span-1 md:col-span-4 flex flex-col items-center text-center p-4 bg-slate-50 border border-slate-100 rounded-xl shrink-0">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">CONVERSATIONAL GRADE</span>
            <div className="relative flex items-center justify-center">
              <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
                <circle
                  stroke="#e2e8f0"
                  fill="transparent"
                  strokeWidth={strokeWidth}
                  r={normalizedRadius}
                  cx={radius}
                  cy={radius}
                />
                <circle
                  stroke={scoreMeta.stroke}
                  fill="transparent"
                  strokeWidth={strokeWidth}
                  strokeDasharray={circumference + " " + circumference}
                  style={{ strokeDashoffset }}
                  strokeLinecap="round"
                  r={normalizedRadius}
                  cx={radius}
                  cy={radius}
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center">
                <span className={`text-3xl font-extrabold tracking-tight ${scoreMeta.text}`}>{overallScore}%</span>
              </div>
            </div>
            
            <div className={`mt-4 px-3 py-1 rounded-full text-xs font-bold border ${scoreMeta.bg} ${scoreMeta.text} border-current/20`}>
              {scoreMeta.label}
            </div>

            <p className="text-xs text-slate-500 mt-2.5 font-medium">
              Rep: <span className="font-bold text-slate-800">{salespersonName || "Active Rep"}</span>
            </p>
          </div>

          {/* AI Executive Summary Block */}
          <div className="col-span-1 md:col-span-8 space-y-4">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-indigo-50 border border-indigo-100 rounded text-indigo-700 text-[10px] font-bold uppercase tracking-wider">
                <Sparkles className="w-3 h-3 text-indigo-600 animate-pulse" />
                AI Analyst Evaluation
              </div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight leading-tight">Executive Briefing</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed whitespace-pre-wrap">
              {summary || "Acoustic audio analyzed successfully. Review the strengths and missed opportunities index on the layout tabs below for targeted behavioral coaching points."}
            </p>
          </div>

        </div>
      </div>

      {/* Strengths Index vs Missed Opportunity Index */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Row 1: Strengths Card Table */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-5">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
            <div className="p-2 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-xl shrink-0">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">Key Technical Accomplishments</h3>
              <p className="text-[11px] text-slate-400">Conversational actions to protect and reinforce.</p>
            </div>
          </div>

          <div className="space-y-4">
            {strengths && strengths.length > 0 ? (
              strengths.map((item, idx) => (
                <div key={idx} className="flex gap-3 p-3 bg-emerald-50/20 border border-emerald-100/60 rounded-xl">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-bold text-slate-900">{item.title}</h4>
                      <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-full border border-emerald-200/40 uppercase">
                        {item.tag}
                      </span>
                    </div>
                    <p className="text-slate-600 font-normal leading-relaxed text-xs">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-400">No accomplishments loaded.</p>
            )}
          </div>
        </div>

        {/* Row 2: Missed Opportunities Card Table */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-5">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
            <div className="p-2 bg-rose-50 text-rose-700 border border-rose-100 rounded-xl shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">Missed Conversational Wins</h3>
              <p className="text-[11px] text-slate-400">Performance triggers leaking potential deal quota.</p>
            </div>
          </div>

          <div className="space-y-4">
            {missedOpportunities && missedOpportunities.length > 0 ? (
              missedOpportunities.map((item, idx) => (
                <div key={idx} className="flex gap-3 p-3 bg-rose-50/20 border border-rose-100/60 rounded-xl">
                  <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-bold text-slate-900">{item.title}</h4>
                      <span className="text-[9px] font-bold bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded-full border border-rose-200/40 uppercase">
                        {item.tag}
                      </span>
                    </div>
                    <p className="text-slate-600 font-normal leading-relaxed text-xs">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-400">No opportunities loaded.</p>
            )}
          </div>
        </div>

      </div>

      {/* Target Action Plan Checklist */}
      {actionPlan && actionPlan.length > 0 && (
        <div id="action-plan-wrapper" className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500 animate-pulse animate-duration-1000" />
            Action Plan: Actionable Next Steps
          </h3>
          <p className="text-xs text-slate-500">
            Micro-training tasks recommended to practice prior to the representative's upcoming CRM pipeline dials.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            {actionPlan.map((step, idx) => {
              const isChecked = !!checkedSteps[idx];
              return (
                <div
                  key={idx}
                  onClick={() => toggleStep(idx)}
                  className={`flex items-start gap-3 p-4 border rounded-xl cursor-pointer select-none transition-all duration-300 ${
                    isChecked
                      ? "bg-slate-50 border-emerald-500 shadow-sm opacity-75"
                      : "bg-white hover:bg-slate-50 border-slate-200/80"
                  }`}
                >
                  <input
                    id={`checkbox-step-${idx}`}
                    type="checkbox"
                    checked={isChecked}
                    readOnly
                    className="h-4 w-4 mt-0.5 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                  />
                  <div className="text-xs leading-relaxed">
                    <span className="font-bold text-slate-400 block mb-1">TASK {idx + 1}</span>
                    <span className={`text-slate-700 font-medium ${isChecked ? "line-through text-slate-400" : ""}`}>
                      {step}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
