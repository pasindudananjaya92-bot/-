import React, { useState, useMemo, useEffect, useRef } from "react";
import { TranscriptLine } from "../types";
import { Search, UserCircle, MessageSquareOff, Volume2, ShieldAlert } from "lucide-react";

interface TranscriptViewProps {
  transcript: TranscriptLine[];
  hoveredSeconds: number | null;
}

export default function TranscriptView({
  transcript = [],
  hoveredSeconds,
}: TranscriptViewProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const activeLineRef = useRef<HTMLDivElement>(null);

  // Filter transcript text based on search term
  const filteredTranscript = useMemo(() => {
    if (!searchTerm) return transcript;
    const lower = searchTerm.toLowerCase();
    return transcript.filter((item) =>
      item.text.toLowerCase().includes(lower)
    );
  }, [transcript, searchTerm]);

  // Find line closest to hoveredSeconds for highlighting
  const highlightedIndex = useMemo(() => {
    if (hoveredSeconds === null) return null;
    let closestIndex = 0;
    let minDifference = Infinity;

    transcript.forEach((line, index) => {
      const diff = Math.abs(line.seconds - hoveredSeconds);
      if (diff < minDifference) {
        minDifference = diff;
        closestIndex = index;
      }
    });

    // Only highlight if the difference is within 25 seconds of the chunk
    return minDifference < 25 ? closestIndex : null;
  }, [transcript, hoveredSeconds]);

  // Auto-scroll highlighted line into focus within the transcript container
  useEffect(() => {
    if (highlightedIndex !== null && activeLineRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
      });
    }
  }, [highlightedIndex]);

  return (
    <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm flex flex-col h-[525px]">
      {/* Header with Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3 shrink-0">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-indigo-500" />
            Diarized Conversation Transcript
          </h2>
          <p className="text-xs text-slate-500">
            Automated speaker separation based on neural acoustic tags.
          </p>
        </div>

        {/* Search Field */}
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            id="search-transcript"
            type="text"
            placeholder="Search transcript..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-slate-50/50"
          />
        </div>
      </div>

      {/* Main Transcript Body */}
      <div className="flex-grow overflow-y-auto mt-4 pr-1 space-y-4 max-h-[420px]" style={{ scrollbarWidth: 'thin' }}>
        {filteredTranscript.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center text-slate-400 space-y-3">
            <MessageSquareOff className="w-10 h-10 text-slate-300" />
            <p className="text-sm font-medium">No matching conversation snippets found.</p>
          </div>
        ) : (
          filteredTranscript.map((line, index) => {
            const isSpeakerRep = line.speaker === "A";
            const isHighlighted = highlightedIndex !== null && transcript[highlightedIndex] === line;

            return (
              <div
                key={index}
                ref={isHighlighted ? activeLineRef : null}
                className={`flex gap-3.5 p-3 rounded-xl transition-all duration-300 border ${
                  isHighlighted
                    ? "bg-amber-50/70 border-amber-300/80 shadow-sm scale-[1.01]"
                    : "bg-slate-50/40 border-slate-100 hover:bg-slate-50"
                }`}
              >
                {/* Speaker Badge Icon */}
                <div className="shrink-0">
                  {isSpeakerRep ? (
                    <div className="w-8 h-8 rounded-full bg-amber-100 border border-amber-200 flex items-center justify-center text-amber-700">
                      <UserCircle className="w-5 h-5" />
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-teal-100 border border-teal-200 flex items-center justify-center text-teal-700">
                      <UserCircle className="w-5 h-5" />
                    </div>
                  )}
                </div>

                {/* Speaker Text Context */}
                <div className="space-y-1 flex-grow">
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold ${isSpeakerRep ? "text-amber-800" : "text-teal-800"}`}>
                      {isSpeakerRep ? "SPEAKER A (Sales Rep)" : "SPEAKER B (Prospect)"}
                    </span>
                    <span className="font-mono text-[10px] text-slate-400 font-semibold bg-slate-100 px-2 py-0.5 rounded-full">
                      {line.timestamp}
                    </span>
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed font-normal whitespace-pre-wrap">
                    {line.text}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Sync tip */}
      <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-400 flex items-center justify-between shrink-0">
        <span className="flex items-center gap-1">
          <ShieldAlert className="w-3.5 h-3.5" />
          Acoustic alignment synced with graph hover coordinate
        </span>
        <span className="font-mono">
          Total logs: {filteredTranscript.length}
        </span>
      </div>
    </div>
  );
}
