import React, { useState } from "react";
import { AnalysisPayload } from "../types";
import AudioPlayer from "./AudioPlayer";
import SentimentGraph from "./SentimentGraph";
import TranscriptView from "./TranscriptView";
import CoachingCard from "./CoachingCard";
import { ArrowLeft, Clock, FileAudio, Check, AlertCircle, RefreshCw } from "lucide-react";

interface DashboardProps {
  fileName: string;
  data: AnalysisPayload;
  isSimulatedFallback: boolean;
  warningText?: string | null;
  onBackToUpload: () => void;
  audioFileUrl: string | null;
}

export default function Dashboard({
  fileName,
  data,
  isSimulatedFallback,
  warningText,
  onBackToUpload,
  audioFileUrl,
}: DashboardProps) {
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [hoveredChartSec, setHoveredChartSec] = useState<number | null>(null);

  const { transcript = [], timelineMetrics = [], coachingCard } = data;

  // Format second parameters to MM:SS string
  const formatSeconds = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const totalCallSeconds = transcript.length > 0 ? transcript[transcript.length - 1].seconds + 10 : 160;

  return (
    <div className="space-y-6">
      
      {/* Visual Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        
        {/* Back and title info */}
        <div className="flex items-center gap-3.5">
          <button
            id="back-to-upload-btn"
            type="button"
            onClick={onBackToUpload}
            className="p-2.5 bg-slate-100 hover:bg-slate-200/90 active:scale-95 text-slate-700 hover:text-slate-900 rounded-xl transition-all cursor-pointer border border-slate-200/50 flex items-center justify-center"
            title="Analyze Another Sales Call"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          
          <div className="space-y-1 text-left">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="p-1 px-2.5 bg-slate-100 border border-slate-200 rounded-md text-[10px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                <FileAudio className="w-3.5 h-3.5 text-slate-400" />
                Active Sales File
              </span>
              <span className="text-xs bg-amber-50 text-amber-800 border border-amber-200/70 font-bold px-2 py-0.5 rounded flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> {formatSeconds(totalCallSeconds)}
              </span>
              {isSimulatedFallback ? (
                <span className="text-xs bg-rose-50 text-rose-800 border border-rose-200 font-semibold px-2 py-0.5 rounded">
                  Demo Sandbox
                </span>
              ) : (
                <span className="text-xs bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold px-2 py-0.5 rounded flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Live Gemini Diarization
                </span>
              )}
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight block truncate max-w-lg">
              {fileName}
            </h1>
          </div>
        </div>

        {/* Retry/Analyze panel */}
        <button
          id="reload-analysis-btn"
          type="button"
          onClick={onBackToUpload}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold font-sans hover:bg-slate-800 transition-all border border-slate-900 shadow-sm"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Analyze New Call
        </button>
      </div>

      {/* Warnings & Notices */}
      {warningText && (
        <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200/80 rounded-xl text-amber-900">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5 animate-bounce" />
          <div className="text-xs leading-relaxed">
            <h4 className="font-bold">Sandbox Notification</h4>
            <p className="text-amber-700 mt-0.5">{warningText}</p>
          </div>
        </div>
      )}

      {/* Integrated dynamic playback block */}
      <AudioPlayer
        transcript={transcript}
        currentTime={currentTimeSec}
        onTimeChange={(sec) => {
          // If the callback gives functional state, update it
          if (typeof sec === "function") {
            setCurrentTimeSec(sec);
          } else {
            setCurrentTimeSec(sec);
          }
        }}
        audioFileUrl={audioFileUrl}
      />

      {/* Dual analytics dashboard grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left pane: Sentiment Graphs (Line Charts) */}
        <div className="lg:col-span-7 space-y-6">
          <SentimentGraph
            metrics={timelineMetrics}
            activeTimelineIndex={0}
            onTimelineHover={(sec) => setHoveredChartSec(sec)}
          />
        </div>

        {/* Right pane: Diarized Dialogue Transcript logs */}
        <div className="lg:col-span-5">
          <TranscriptView
            transcript={transcript}
            hoveredSeconds={hoveredChartSec !== null ? hoveredChartSec : currentTimeSec}
          />
        </div>

      </div>

      {/* Bottom pane: Sales Performance Coaching Card */}
      {coachingCard && (
        <div id="coaching-card-wrapper">
          <CoachingCard cardData={coachingCard} />
        </div>
      )}

    </div>
  );
}
