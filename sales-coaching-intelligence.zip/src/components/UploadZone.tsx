import React, { useState, useRef } from "react";
import { Upload, FileAudio, Sparkles, AlertCircle, Loader2 } from "lucide-react";

interface UploadZoneProps {
  onAnalyzeStart: (fileName: string) => void;
  onAnalyzeSuccess: (data: any, isSimulated?: boolean, warning?: string) => void;
  onAnalyzeError: (error: string) => void;
  isLoading: boolean;
}

export default function UploadZone({
  onAnalyzeStart,
  onAnalyzeSuccess,
  onAnalyzeError,
  isLoading,
}: UploadZoneProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [errorLocal, setErrorLocal] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Trigger base64 extraction and upload to Node API
  const processAudioFile = async (file: File) => {
    if (!file.type.startsWith("audio/") && !file.name.endsWith(".mp3") && !file.name.endsWith(".wav") && !file.name.endsWith(".m4a")) {
      const err = "Please upload a valid audio file (.mp3, .wav, or .m4a)";
      setErrorLocal(err);
      onAnalyzeError(err);
      return;
    }

    setErrorLocal(null);
    onAnalyzeStart(file.name);

    try {
      const base64Data = await convertFileToBase64(file);
      const payload = {
        audioBase64: base64Data,
        mimeType: file.type || "audio/mp3",
        fileName: file.name,
      };

      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const body = await response.json();
      if (!response.ok || !body.success) {
        throw new Error(body.error || "Failed to analyze audio call via Gemini API.");
      }

      onAnalyzeSuccess(body.data, body.isSimulated, body.warning);
    } catch (err: any) {
      console.error("Audio Analysis error:", err);
      const errMsg = err.message || "An unexpected error occurred during audio classification.";
      setErrorLocal(errMsg);
      onAnalyzeError(errMsg);
    }
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const resultString = reader.result as string;
        // Strip data meta headers from base64 string
        const base64 = resultString.split(",")[1];
        resolve(base64);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processAudioFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processAudioFile(e.target.files[0]);
    }
  };

  // Instant pre-cached analyzer preset
  const loadPreset = async (presetId: string) => {
    onAnalyzeStart(presetId === "saas" ? "SaaS_Enterprise_Call.mp3" : "DevOps_Cold_Call.mp3");
    setErrorLocal(null);

    try {
      const response = await fetch(`/api/preset/${presetId}`);
      const body = await response.json();
      if (!response.ok || !body.success) {
        throw new Error(body.error || "Failed to load demonstration preset.");
      }
      // Add slight artistic timeout delay to simulate authentic live pipeline analysis
      setTimeout(() => {
        onAnalyzeSuccess(body.data, false);
      }, 1200);
    } catch (err: any) {
      setErrorLocal(err.message);
      onAnalyzeError(err.message);
    }
  };

  return (
    <div id="upload-zone-wrapper" className="max-w-3xl mx-auto space-y-8 py-4">
      {/* Dynamic Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 rounded-full border border-amber-200/60 text-amber-800 text-xs font-semibold tracking-wide">
          <Sparkles className="w-3.5 h-3.5 animate-pulse" />
          Omni-Channel Sales Intelligence
        </div>
        <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
          Sales Coaching Intelligence
        </h1>
        <p className="text-base text-slate-600 max-w-xl mx-auto">
          Upload calls to generate instant diarized transcriptions, sentiment engagement timelines, and actionable AI strengths scorecarding.
        </p>
      </div>

      {/* Main Drag-zone Box */}
      <div
        id="drag-drop-container"
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={() => !isLoading && fileInputRef.current?.click()}
        className={`relative flex flex-col items-center justify-center border-2 border-dashed rounded-2xl p-10 cursor-pointer transitions-all duration-300 ${
          isDragActive
            ? "border-amber-500 bg-amber-50/50 scale-[0.99] shadow-inner"
            : "border-slate-300 hover:border-amber-400 bg-white shadow-sm hover:shadow-md"
        } ${isLoading ? "pointer-events-none opacity-80" : ""}`}
      >
        <input
          id="audio-file-uploader"
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="audio/*"
          className="hidden"
          disabled={isLoading}
        />

        {isLoading ? (
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="relative">
              <div className="absolute inset-0 bg-amber-200/55 rounded-full blur-xl animate-pulse"></div>
              <Loader2 className="w-14 h-14 text-amber-600 animate-spin relative z-10" />
            </div>
            <div className="space-y-1.5 z-10">
              <h3 className="text-lg font-bold text-slate-800 animate-pulse">Analyzing Conversational Dynamics...</h3>
              <p className="text-xs text-slate-500 max-w-sm">
                Gemini is diarizing speakers, plotting acoustic sentiment indices, and assembling your constructive scorecard.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center space-y-4 text-center select-none">
            <div className="p-4 bg-amber-50 text-amber-700 rounded-full border border-amber-100">
              <FileAudio className="w-10 h-10" />
            </div>
            <div className="space-y-1">
              <p className="text-base font-semibold text-slate-800">
                Drag & drop sales recording, or <span className="text-amber-600 hover:text-amber-700">browse folders</span>
              </p>
              <p className="text-xs text-slate-400">
                Supports MP3, WAV, or M4A high-fidelity records up to 50MB
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Error Output */}
      {errorLocal && (
        <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-100 rounded-xl text-red-800">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div className="space-y-1 text-sm">
            <h4 className="font-bold">Transaction Halt</h4>
            <p className="text-red-700">{errorLocal}</p>
          </div>
        </div>
      )}

      {/* Demo Sandbox Presets */}
      <div className="space-y-4 pt-2">
        <div className="relative flex py-2 items-center">
          <div className="flex-grow border-t border-slate-200"></div>
          <span className="flex-shrink mx-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
            no recording? Explore sandbox presets
          </span>
          <div className="flex-grow border-t border-slate-200"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Preset 1 */}
          <button
            id="preset-saas-btn"
            type="button"
            onClick={() => !isLoading && loadPreset("saas")}
            disabled={isLoading}
            className="flex items-start p-4 bg-slate-50 hover:bg-slate-100/90 border border-slate-200/80 rounded-xl text-left transition-all hover:scale-[1.01] hover:shadow-sm"
          >
            <div className="p-2 mr-3 bg-amber-100 text-amber-800 rounded-lg shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 text-sm">SaaS Demo Discovery</h4>
              <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                Enterprise alignment call. Established rapport, isolated visibility blockages, closed with pilot incentives.
              </p>
              <span className="inline-block mt-3 px-2 py-0.5 bg-emerald-50 text-emerald-800 text-[10px] font-semibold rounded-md">
                Representative: Arthur Curry • Grade: 92%
              </span>
            </div>
          </button>

          {/* Preset 2 */}
          <button
            id="preset-cold-btn"
            type="button"
            onClick={() => !isLoading && loadPreset("cold")}
            disabled={isLoading}
            className="flex items-start p-4 bg-slate-50 hover:bg-slate-100/90 border border-slate-200/80 rounded-xl text-left transition-all hover:scale-[1.01] hover:shadow-sm"
          >
            <div className="p-2 mr-3 bg-blue-100 text-blue-800 rounded-lg shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 text-sm">Tech DevOps Cold Call</h4>
              <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                High friction opening. Disarmed objection via technical value injection, booked secondary callback.
              </p>
              <span className="inline-block mt-3 px-2 py-0.5 bg-amber-50 text-amber-800 text-[10px] font-semibold rounded-md">
                Representative: Marcus Fenix • Grade: 88%
              </span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
