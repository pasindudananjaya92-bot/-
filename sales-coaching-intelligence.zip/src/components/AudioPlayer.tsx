import React, { useState, useEffect, useRef } from "react";
import { Play, Pause, RotateCcw, Volume2, HardDriveUpload } from "lucide-react";
import { TranscriptLine } from "../types";

interface AudioPlayerProps {
  transcript: TranscriptLine[];
  currentTime: number;
  onTimeChange: (seconds: number) => void;
  audioFileUrl: string | null;  // If a real audio file blob URL exists
}

export default function AudioPlayer({
  transcript = [],
  currentTime = 0,
  onTimeChange,
  audioFileUrl,
}: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const currentTimeRef = useRef(currentTime);

  // Synchronize internal timing references
  useEffect(() => {
    currentTimeRef.current = currentTime;
  }, [currentTime]);

  // Parse maximum duration from transcript data
  const maxDuration = transcript.length > 0
    ? transcript[transcript.length - 1].seconds + 10
    : 160;

  // Handle Play/Pause operations
  const handlePlayPause = () => {
    setIsPlaying((prev) => !prev);
  };

  // Synchronize actual audio element if present
  useEffect(() => {
    if (audioFileUrl && audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch((err) => {
          console.warn("Audio Context playback error:", err);
          setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, audioFileUrl]);

  // Synchronize playback speed
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Combined ticker for real audio OR simulated preset timeline tracking
  useEffect(() => {
    if (isPlaying) {
      if (audioFileUrl) {
        // Active real audio tracking
        const updateTick = () => {
          if (audioRef.current) {
            onTimeChange(Math.floor(audioRef.current.currentTime));
          }
        };

        const interval = setInterval(updateTick, 250);
        return () => clearInterval(interval);
      } else {
        // Simulated tracking for demo presets
        const tickRate = 1000 / playbackSpeed;
        intervalRef.current = setInterval(() => {
          const nextSecs = currentTimeRef.current + 1;
          if (nextSecs >= maxDuration) {
            setIsPlaying(false);
            onTimeChange(0);
          } else {
            onTimeChange(nextSecs);
          }
        }, tickRate);

        return () => {
          if (intervalRef.current) clearInterval(intervalRef.current);
        };
      }
    }
  }, [isPlaying, audioFileUrl, playbackSpeed, maxDuration]);

  // Pause on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  // Format second parameters to standard MM:SS string
  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleScrubChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const nextSecs = parseInt(e.target.value);
    onTimeChange(nextSecs);
    if (audioFileUrl && audioRef.current) {
      audioRef.current.currentTime = nextSecs;
    }
  };

  const resetTimeline = () => {
    setIsPlaying(false);
    onTimeChange(0);
    if (audioFileUrl && audioRef.current) {
      audioRef.current.currentTime = 0;
    }
  };

  // Generate vertical mock bars for cosmetic equalizer
  const cosmeticBars = Array.from({ length: 48 }, (_, i) => {
    const seedHeight = 15 + Math.sin(i * 1.5) * 10 + Math.cos(i * 0.8) * 5;
    return {
      id: i,
      height: Math.max(4, seedHeight),
    };
  });

  return (
    <div id="integrated-playback-deck" className="bg-slate-900 text-slate-100 rounded-2xl p-5 border border-slate-800 shadow-md">
      
      {/* Real Audio Node */}
      {audioFileUrl && (
        <audio
          id="real-audio-playback"
          ref={audioRef}
          src={audioFileUrl}
          onEnded={() => setIsPlaying(false)}
          className="hidden"
        />
      )}

      <div className="flex flex-col md:flex-row items-center gap-6 justify-between">
        
        {/* Core Buttons */}
        <div className="flex items-center gap-3.5">
          <button
            id="play-pause-btn"
            type="button"
            onClick={handlePlayPause}
            className="w-12 h-12 bg-amber-500 hover:bg-amber-600 active:scale-95 text-slate-950 font-black rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg hover:shadow-amber-500/10"
          >
            {isPlaying ? <Pause className="w-5.5 h-5.5" /> : <Play className="w-5.5 h-5.5 fill-current ml-0.5" />}
          </button>

          <button
            id="reset-playback-btn"
            type="button"
            onClick={resetTimeline}
            className="p-2.5 bg-slate-800 hover:bg-slate-700/80 rounded-xl transition-all border border-slate-700/50 text-slate-400 hover:text-slate-200"
            title="Reset Timeline"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Speed settings multiplier */}
          <div className="flex bg-slate-800 border border-slate-700/50 rounded-xl p-0.5 text-xs">
            {([1, 1.5, 2] as const).map((spd) => (
              <button
                key={spd}
                type="button"
                onClick={() => setPlaybackSpeed(spd)}
                className={`px-2.5 py-1.5 rounded-lg font-bold transition-all ${
                  playbackSpeed === spd
                    ? "bg-amber-500 text-slate-950 font-extrabold"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>
        </div>

        {/* Timelines and equalizer waves wrapper */}
        <div className="flex-grow w-full space-y-2">
          {/* Wave equalizer cosmetic */}
          <div className="h-8 flex items-end justify-between px-2 gap-0.5 shrink-0 select-none opacity-90">
            {cosmeticBars.map((bar) => {
              // Add randomized kinetic bouncing animation if playing
              const dynamicGain = isPlaying ? Math.random() * 0.95 + 0.1 : 0.05;
              const isPastScrub = (currentTime / maxDuration) * 48 > bar.id;
              
              return (
                <div
                  key={bar.id}
                  className={`w-1 rounded-full transition-all duration-300 ${
                    isPastScrub ? "bg-amber-400" : "bg-slate-700/70"
                  }`}
                  style={{
                    height: isPlaying ? `${bar.height * dynamicGain}px` : "6px",
                  }}
                ></div>
              );
            })}
          </div>

          {/* Progress row */}
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-semibold text-slate-400 select-none">
              {formatTime(currentTime)}
            </span>
            <input
              id="scrub-slider"
              type="range"
              min={0}
              max={maxDuration}
              value={currentTime}
              onChange={handleScrubChange}
              className="flex-grow accent-amber-500 bg-slate-800 rounded-lg cursor-pointer h-1.5"
            />
            <span className="font-mono text-xs font-semibold text-slate-400 select-none">
              {formatTime(maxDuration)}
            </span>
          </div>
        </div>

        {/* Status flags */}
        <div id="player-source-card" className="flex items-center gap-2 px-3.5 py-2 bg-slate-800/60 border border-slate-700/50 rounded-xl shrink-0 self-stretch sm:self-auto justify-center">
          <Volume2 className="w-4 h-4 text-amber-500 animate-pulse" />
          <div className="text-left">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">AUDIO SOURCE</div>
            <div className="text-xs font-bold text-slate-200 mt-0.5">
              {audioFileUrl ? "Real Upload Stream" : "Synthesized Dial Trace"}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
