import React, { useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  ReferenceLine,
} from "recharts";
import { TimelineMetric } from "../types";
import { Smile, TrendingUp, Info } from "lucide-react";

interface SentimentGraphProps {
  metrics: TimelineMetric[];
  activeTimelineIndex: number;
  onTimelineHover?: (seconds: number | null) => void;
}

export default function SentimentGraph({
  metrics = [],
  activeTimelineIndex = 0,
  onTimelineHover,
}: SentimentGraphProps) {
  const [activeTab, setActiveTab] = useState<"engagement" | "sentiment">("engagement");

  if (!metrics || metrics.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 bg-slate-50 rounded-xl border border-dashed border-slate-200">
        <p className="text-slate-400 text-sm font-medium">Timeline metrics payload empty.</p>
      </div>
    );
  }

  // Pre-process for rendering
  const chartData = metrics.map((point) => ({
    ...point,
    "Salesperson Engagement": point.engagementSalesperson,
    "Prospect Engagement": point.engagementProspect,
    "Salesperson Sentiment": point.sentimentSalesperson,
    "Prospect Sentiment": point.sentimentProspect,
  }));

  // Custom tooltips to present topic context
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const topic = payload[0].payload.topic;
      return (
        <div id="chart-tooltip" className="bg-slate-950/95 text-white p-3 rounded-lg shadow-xl border border-slate-800 text-xs max-w-xs space-y-1">
          <div className="font-bold flex items-center justify-between border-b border-white/10 pb-1 mb-1 gap-4">
            <span>Timestamp: {label}</span>
            <span className="text-[10px] uppercase font-semibold text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded">
              {topic}
            </span>
          </div>
          {payload.map((item: any, idx: number) => (
            <div key={idx} className="flex items-center justify-between gap-5 py-0.5">
              <span className="flex items-center gap-1.5 font-medium" style={{ color: item.color }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></span>
                {item.name}:
              </span>
              <span className="font-bold font-mono">{item.value}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
      {/* Chart Headers */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-100 gap-4">
        <div className="space-y-1.5">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-amber-500" />
            Call Sentiment & Engagement Analytics
          </h2>
          <p className="text-xs text-slate-500">
            Acoustic flow dynamics plotted over the conversation timeframe. Hover nodes to view context.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="inline-flex bg-slate-100 p-1 rounded-xl shrink-0 self-start sm:self-auto">
          <button
            id="tab-engagement-btn"
            type="button"
            onClick={() => setActiveTab("engagement")}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === "engagement"
                ? "bg-white text-slate-900 shadow-sm"
                : "text-slate-600 hover:text-slate-950"
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
            Engagement (1-10)
          </button>
          <button
            id="tab-sentiment-btn"
            type="button"
            onClick={() => setActiveTab("sentiment")}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === "sentiment"
                ? "bg-white text-slate-900 shadow-sm"
                : "text-slate-600 hover:text-slate-950"
            }`}
          >
            <Smile className="w-3.5 h-3.5 text-blue-500" />
            Sentiment (-5 to +5)
          </button>
        </div>
      </div>

      {/* Main Charts Body */}
      <div className="mt-6">
        <div className="h-[350px]">
          {activeTab === "engagement" ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -25, bottom: 5 }}
                onMouseMove={(state: any) => {
                  if (state && state.activePayload && state.activePayload[0] && onTimelineHover) {
                    onTimelineHover(state.activePayload[0].payload.seconds);
                  }
                }}
                onMouseLeave={() => {
                  if (onTimelineHover) onTimelineHover(null);
                }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="timestamp"
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  padding={{ left: 10, right: 10 }}
                />
                <YAxis
                  stroke="#94a3b8"
                  domain={[0, 10]}
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  tickCount={6}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" wrapperStyle={{ paddingTop: "15px", fontSize: "12px" }} />
                <Line
                  type="monotone"
                  dataKey="Salesperson Engagement"
                  stroke="#f59e0b"
                  strokeWidth={3}
                  activeDot={{ r: 8 }}
                  dot={{ r: 4 }}
                />
                <Line
                  type="monotone"
                  dataKey="Prospect Engagement"
                  stroke="#10b981"
                  strokeWidth={3}
                  activeDot={{ r: 8 }}
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -25, bottom: 5 }}
                onMouseMove={(state: any) => {
                  if (state && state.activePayload && state.activePayload[0] && onTimelineHover) {
                    onTimelineHover(state.activePayload[0].payload.seconds);
                  }
                }}
                onMouseLeave={() => {
                  if (onTimelineHover) onTimelineHover(null);
                }}
              >
                <defs>
                  <linearGradient id="colorSalesperson" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorProspect" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="timestamp"
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="#94a3b8"
                  domain={[-5, 5]}
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  tickCount={11}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" wrapperStyle={{ paddingTop: "15px", fontSize: "12px" }} />
                <ReferenceLine y={0} stroke="#cbd5e1" strokeDasharray="2 2" />
                <Area
                  type="monotone"
                  dataKey="Salesperson Sentiment"
                  stroke="#6366f1"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorSalesperson)"
                />
                <Area
                  type="monotone"
                  dataKey="Prospect Sentiment"
                  stroke="#0ea5e9"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorProspect)"
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Meta context cards below charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 bg-slate-50 p-4 rounded-xl border border-slate-100">
        <div className="flex gap-2.5 items-start text-xs text-slate-600">
          <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="text-slate-800">Engagement Quotient:</strong> Salesperson engagement checks vocal confidence and reaction speed, whilst prospect engagement checks query response depth.
          </p>
        </div>
        <div className="flex gap-2.5 items-start text-xs text-slate-600">
          <Smile className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong className="text-slate-800">Sentiment Positive Bias:</strong> Tracks sentiment valence from -5 (resistance, hostile, silent block) up to +5 (excited, validation, intent alignment).
          </p>
        </div>
      </div>
    </div>
  );
}
