export interface TranscriptLine {
  speaker: "A" | "B";
  timestamp: string;
  seconds: number;
  text: string;
}

export interface TimelineMetric {
  timestamp: string;
  seconds: number;
  engagementSalesperson: number;
  engagementProspect: number;
  sentimentSalesperson: number;
  sentimentProspect: number;
  topic: string;
}

export interface CoachingItem {
  title: string;
  description: string;
  tag: string;
}

export interface CoachingCardData {
  salespersonName: string;
  overallScore: number;
  summary: string;
  strengths: CoachingItem[];
  missedOpportunities: CoachingItem[];
  actionPlan: string[];
}

export interface AnalysisPayload {
  transcript: TranscriptLine[];
  timelineMetrics: TimelineMetric[];
  coachingCard: CoachingCardData;
}
