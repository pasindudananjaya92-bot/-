import React, { useState } from "react";
import UploadZone from "./components/UploadZone";
import Dashboard from "./components/Dashboard";
import { AnalysisPayload } from "./types";
import { Sparkles, BarChart3, HelpCircle, ShieldCheck } from "lucide-react";

export default function App() {
  const [activeFile, setActiveFile] = useState<string | null>(null);
  const [audioFileUrl, setAudioFileUrl] = useState<string | null>(null);
  const [analysisData, setAnalysisData] = useState<AnalysisPayload | null>(null);
  const [isSimulated, setIsSimulated] = useState(false);
  const [warningText, setWarningText] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [systemError, setSystemError] = useState<string | null>(null);

  // Trigger loading phase
  const handleAnalyzeStart = (fileName: string) => {
    setIsLoading(true);
    setSystemError(null);
    setActiveFile(fileName);

    // If a real audio file was uploaded, grab it from HTML element if possible
    const fileUploader = document.getElementById("audio-file-uploader") as HTMLInputElement;
    if (fileUploader && fileUploader.files && fileUploader.files[0]) {
      const file = fileUploader.files[0];
      const localUrl = URL.createObjectURL(file);
      setAudioFileUrl(localUrl);
    } else {
      setAudioFileUrl(null); // Clear local file blobs for pre-loaded simulated data presets
    }
  };

  // Trigger analysis load achievement
  const handleAnalyzeSuccess = (data: any, isSimulatedFallback = false, warning?: string) => {
    setAnalysisData(data);
    setIsSimulated(isSimulatedFallback);
    setWarningText(warning || null);
    setIsLoading(false);
  };

  // Trigger analytical failures
  const handleAnalyzeError = (error: string) => {
    setSystemError(error);
    setIsLoading(false);
    setActiveFile(null);
    setAudioFileUrl(null);
  };

  // Navigate back to upload landing page
  const handleBackToUpload = () => {
    setActiveFile(null);
    if (audioFileUrl) {
      URL.revokeObjectURL(audioFileUrl);
    }
    setAudioFileUrl(null);
    setAnalysisData(null);
    setIsSimulated(false);
    setWarningText(null);
    setSystemError(null);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans text-slate-800 antialiased selection:bg-amber-100">
      
      {/* Platform Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-slate-200/80 px-6 py-4 shadow-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-slate-900 text-amber-400 rounded-xl flex items-center justify-center shadow-md">
              <BarChart3 className="w-5.5 h-5.5" />
            </div>
            <div className="text-left">
              <span className="font-sans font-black text-slate-900 tracking-tight text-lg flex items-center gap-1">
                CLOSEINTEL <span className="text-amber-500 font-medium text-xs">AI</span>
              </span>
              <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider leading-none">
                Enterprise Conversation Coaching
              </p>
            </div>
          </div>

          {/* Secure pipeline check */}
          <div className="flex items-center gap-4">
            <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 bg-slate-150 border border-slate-200 text-slate-500 rounded-full text-xs font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              Secure CRM Integrations Isolated
            </div>
          </div>

        </div>
      </header>

      {/* Main Container Stage */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 py-10">
        
        {analysisData && activeFile ? (
          // Active Analytics Workspace View
          <Dashboard
            fileName={activeFile}
            data={analysisData}
            isSimulatedFallback={isSimulated}
            warningText={warningText}
            onBackToUpload={handleBackToUpload}
            audioFileUrl={audioFileUrl}
          />
        ) : (
          // Landing/Upload workspace View
          <div className="space-y-6">
            <UploadZone
              onAnalyzeStart={handleAnalyzeStart}
              onAnalyzeSuccess={handleAnalyzeSuccess}
              onAnalyzeError={handleAnalyzeError}
              isLoading={isLoading}
            />

            {/* Platform Feature Guide */}
            {!isLoading && (
              <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 pt-10 text-left border-t border-slate-200/50 mt-10">
                <div className="space-y-1.5">
                  <div className="font-bold text-slate-950 text-sm flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded bg-amber-500/10 text-amber-700 flex items-center justify-center font-bold text-xs">1</span>
                    Continuous Diarization
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    Neural acoustic maps isolate sound patterns to perfectly categorize dialogue segments between Salespeople and Prospects.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <div className="font-bold text-slate-950 text-sm flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded bg-blue-500/10 text-blue-700 flex items-center justify-center font-bold text-xs">2</span>
                    Dual Timeline Plotting
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    Visualizes vocal pitch vectors, objection speeds, and interest level indices dynamically over the entire call timeline.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <div className="font-bold text-slate-950 text-sm flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded bg-indigo-500/10 text-indigo-700 flex items-center justify-center font-bold text-xs">3</span>
                    Instant coaching cards
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    Identifies exactly 3 positive actions to scaling, 3 missed performance triggers, and designs a customized mock training plan.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

      </main>

      {/* Brand Footer */}
      <footer className="bg-white border-t border-slate-200/80 py-6 px-6 text-center text-xs text-slate-400 shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 font-medium">
          <span>© 2026 CloseIntel AI, Inc. All rights reserved.</span>
          <div className="flex gap-4 items-center">
            <span className="hover:text-slate-600 cursor-pointer">Security Portal</span>
            <span>•</span>
            <span className="hover:text-slate-600 cursor-pointer">Coaching Compliance</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
