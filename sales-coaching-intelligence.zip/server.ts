import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const isProd = process.env.NODE_ENV === "production";
const PORT = 3000;

// Initialize Gemini SDK with telemetry header "User-Agent" set to "aistudio-build"
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    })
  : null;

// High quality high fidelity presets for demonstration/testing
const DEMO_PRESETS: Record<string, any> = {
  saas: {
    transcript: [
      { speaker: "A", timestamp: "00:03", seconds: 3, text: "Hi Sarah, thank you for jumping on the call with me today! I'm excited to learn more about how your team at AcmeCorp is scaling." },
      { speaker: "B", timestamp: "00:09", seconds: 9, text: "Thanks Arthur. Yeah, we've grown from 10 to about 45 reps recently, and keeping track of customer interactions has been quite a headache." },
      { speaker: "A", timestamp: "00:16", seconds: 16, text: "Wow, that is some impressive growth! That type of scaling usually means a lot of details start slipping through the cracks. How are you currently managing that visibility?" },
      { speaker: "B", timestamp: "00:24", seconds: 24, text: "Well, we aren't really. Reps write manual call summaries, but it's very subjective. Mostly, we just hope for the best, resulting in lots of missed follow-ups." },
      { speaker: "A", timestamp: "00:32", seconds: 32, text: "That makes complete sense and is extremely common. What would it mean if you could instantly capture 100% of those action items automatically with high accuracy?" },
      { speaker: "B", timestamp: "00:39", seconds: 39, text: "Honestly, that would be a game-changer. It would probably save each rep 3 hours a week, and as an executive, I'd actually have peace of mind. But how complex is the integration?" },
      { speaker: "A", timestamp: "00:48", seconds: 48, text: "It's literally a one-click connection to Salesforce or HubSpot. It takes less than 3 minutes to go live, with no IT bottleneck whatsoever. Let me show you a quick 2-minute demo." },
      { speaker: "B", timestamp: "00:58", seconds: 58, text: "Oh really? Okay, that sounds promising. Let me see it." },
      { speaker: "A", timestamp: "01:05", seconds: 65, text: "Excellent. Here is the dashboard... [Arthur screenshares and walks Sarah through the AI pipeline, highlighting live automated coaching and action items]." },
      { speaker: "B", timestamp: "01:25", seconds: 85, text: "Wow, that transcript is extremely fast. Is this diarized automatically? Does it separate the customer from our rep?" },
      { speaker: "A", timestamp: "01:31", seconds: 91, text: "Yes, absolutely. It uses voice biometrics to instantly distinguish roles, even if multiple people speak over each other. It also tracks talk-to-listen ratios so managers can coach on active listening." },
      { speaker: "B", timestamp: "01:42", seconds: 102, text: "That is amazing. Arthur, what does pricing look like for about 50 users? We have a strict software budget this quarter." },
      { speaker: "A", timestamp: "01:50", seconds: 110, text: "I can absolutely put together a tailored proposal for 50 licenses. Tell me, do you have a specific target budget you're trying to stay within, or a current baseline cost we need to compare against?" },
      { speaker: "B", timestamp: "02:02", seconds: 122, text: "We were hoping to stay under $1,200 a month. Some other tools we looked at were twice that, which we just can't justify right now." },
      { speaker: "A", timestamp: "02:11", seconds: 131, text: "I completely understand that budgets are tight. Let me tell you: our standard enterprise rate is slightly higher, but since you are scaling, we can offer a pilot discount that brings us right to $1,150 a month, fully inclusive. Does that align with your approval loops?" },
      { speaker: "B", timestamp: "02:26", seconds: 146, text: "Yes, $1,150 fits cleanly inside my spending authority! I don't even need to run it up to our CFO. If you can send that agreement over, we could get started as early as this Thursday." },
      { speaker: "A", timestamp: "02:37", seconds: 157, text: "That is fantastic! I will draw up the agreement immediately. It was wonderful speaking with you, Sarah. Welcome aboard!" },
      { speaker: "B", timestamp: "02:44", seconds: 164, text: "Wonderful. Really excited about this Arthur. Have a great day!" }
    ],
    timelineMetrics: [
      { timestamp: "00:00", seconds: 0, engagementSalesperson: 8.5, engagementProspect: 6.0, sentimentSalesperson: 3.5, sentimentProspect: 1.5, topic: "Icebreaker & Welcome" },
      { timestamp: "00:15", seconds: 15, engagementSalesperson: 9.0, engagementProspect: 7.5, sentimentSalesperson: 4.0, sentimentProspect: 2.0, topic: "Discovery: Growth Challenges" },
      { timestamp: "00:30", seconds: 30, engagementSalesperson: 8.0, engagementProspect: 8.5, sentimentSalesperson: 3.5, sentimentProspect: 1.0, topic: "Identifying Paint Points" },
      { timestamp: "00:45", seconds: 45, engagementSalesperson: 9.5, engagementProspect: 9.0, sentimentSalesperson: 4.5, sentimentProspect: 3.5, topic: "Value Proposition Intro" },
      { timestamp: "01:00", seconds: 60, engagementSalesperson: 9.0, engagementProspect: 8.5, sentimentSalesperson: 4.0, sentimentProspect: 3.0, topic: "Product Demonstration" },
      { timestamp: "01:15", seconds: 75, engagementSalesperson: 8.5, engagementProspect: 9.5, sentimentSalesperson: 4.5, sentimentProspect: 4.5, topic: "Live Transcription Feature" },
      { timestamp: "01:30", seconds: 90, engagementSalesperson: 8.0, engagementProspect: 9.0, sentimentSalesperson: 4.0, sentimentProspect: 4.0, topic: "Speaker Diarization Tech" },
      { timestamp: "01:45", seconds: 105, engagementSalesperson: 7.5, engagementProspect: 7.5, sentimentSalesperson: 3.0, sentimentProspect: 1.5, topic: "Objection: Budget Constraints" },
      { timestamp: "02:00", seconds: 120, engagementSalesperson: 9.2, engagementProspect: 8.8, sentimentSalesperson: 3.8, sentimentProspect: 2.5, topic: "Value Framing Pricing" },
      { timestamp: "02:15", seconds: 135, engagementSalesperson: 9.5, engagementProspect: 9.8, sentimentSalesperson: 4.8, sentimentProspect: 4.8, topic: "Discount & Agreement Match" },
      { timestamp: "02:30", seconds: 150, engagementSalesperson: 9.0, engagementProspect: 9.5, sentimentSalesperson: 4.5, sentimentProspect: 4.5, topic: "Closing & Next Steps" }
    ],
    coachingCard: {
      salespersonName: "Arthur Curry",
      overallScore: 92,
      summary: "An exceptional discovery and demo call. Arthur established rapid rapport, uncovered painful visibility blind spots, and managed to map pricing precisely to Sarah's instant signing authority.",
      strengths: [
        { title: "Empathetic Discovery", description: "Arthur validated the prospect's pain point ('keeping track of interactions has been quite a headache') instead of jumping straight into a feature presentation.", tag: "Discovery" },
        { title: "Visual Demo Alignment", description: "Arthur seamlessly transitioned into the live interface, matching Acme's specific pains (visibility, action tracking) to corresponding features in the product.", tag: "Presentation" },
        { title: "Perfect Budget Framing", description: "Faced with a budget objection, he dug deeper to find her baseline spending authority ($1,200) then framed a package that fit exactly within it to bypass procurement delays.", tag: "Closing" }
      ],
      missedOpportunities: [
        { title: "Rushed Contract Detail", description: "Arthur immediately accepted the oral agreement without laying out critical setup requirements or assigning pre-work for the Thursday implementation.", tag: "Setup" },
        { title: "Talk Ratio Variance", description: "During the demo walk-through (01:05 to 01:25), Arthur spoke continuously for over 20 seconds, temporarily depressing the prospect's verbal engagement score.", tag: "Active Listening" },
        { title: "Missing Referral Ask", description: "Given the immense level of enthusiasm and Sarah's instant close, Arthur missed a optimal window to ask for referrals in their parent company.", tag: "Referral" }
      ],
      actionPlan: [
        "Create a simple pre-onboarding slide deck to send instantly with the Thursday agreement.",
        "Practice a 10-second pause after sharing your screen to let the prospect speak or react first.",
        "Include a systematic referral prompt into your closing milestone standard operating procedure."
      ]
    }
  },
  cold: {
    transcript: [
      { speaker: "A", timestamp: "00:02", seconds: 2, text: "Hey there! This is Marcus from TechSphere. I know you weren't expecting my call, but do you have 45 seconds to talk about how you're backing up your local dev databases?" },
      { speaker: "B", timestamp: "00:10", seconds: 10, text: "Honestly, Marcus, I'm literally walking into a board meeting right now. Can we do this some other time?" },
      { speaker: "A", timestamp: "00:15", seconds: 15, text: "Oh, I completely respect that! Board meetings are extremely stressful. Let me give you just the 10-second elevator pitch, and if it makes sense, we'll schedule a proper 10 minutes next Tuesday." },
      { speaker: "B", timestamp: "00:27", seconds: 27, text: "Sigh... okay, literally 10 seconds. Go ahead." },
      { speaker: "A", timestamp: "00:31", seconds: 31, text: "Perfect. We built an agent that backs up database clusters in 4 seconds under heavy load with zero read lockups. It reduces cloud backup bills by 40% on average. That's it!" },
      { speaker: "B", timestamp: "00:43", seconds: 43, text: "Wait... zero read lockups? Our PostgreSQL instance locks up every night during backup cycles for 3 minutes. That's actually a major issue for us." },
      { speaker: "A", timestamp: "00:51", seconds: 51, text: "BINGO! That database lockup is exactly why we started compiling TechSphere. It breaks real-time sync. What database engine are you running? Is it PostgreSQL on AWS RDS?" },
      { speaker: "B", timestamp: "01:03", seconds: 103, text: "Yes, exactly! Postgres on Amazon. It's a nightmare because our night developers in EU get disconnected repeatedly." },
      { speaker: "A", timestamp: "01:10", seconds: 110, text: "Exactly! And having developers blocked costs real money. I tell you what: I won't hold you from your board meeting another second. Let's schedule a 15-minute diagnostic next Tuesday at 10 AM. I can show you how to resolve that PG lockup live." },
      { speaker: "B", timestamp: "01:22", seconds: 122, text: "Yes, let's do it. Tuesday at 10 AM works. Send a calendar invite to devops@company.io. This is actually worth looking into." },
      { speaker: "A", timestamp: "01:30", seconds: 130, text: "Awesome! I will send the invite immediately. Best of luck in the board meeting! Talk to you on Tuesday." },
      { speaker: "B", timestamp: "01:36", seconds: 136, text: "Thanks Marcus. Bye." }
    ],
    timelineMetrics: [
      { timestamp: "00:00", seconds: 0, engagementSalesperson: 7.0, engagementProspect: 2.0, sentimentSalesperson: 2.0, sentimentProspect: -1.0, topic: "Cold Opener" },
      { timestamp: "00:15", seconds: 15, engagementSalesperson: 8.5, engagementProspect: 3.5, sentimentSalesperson: 3.0, sentimentProspect: -0.5, topic: "Meeting Objection" },
      { timestamp: "00:30", seconds: 30, engagementSalesperson: 9.0, engagementProspect: 6.0, sentimentSalesperson: 3.5, sentimentProspect: 0.5, topic: "10-Second Pitch" },
      { timestamp: "00:45", seconds: 45, engagementSalesperson: 8.0, engagementProspect: 8.5, sentimentSalesperson: 4.0, sentimentProspect: 2.0, topic: "Zero Read Lockups Hook" },
      { timestamp: "01:00", seconds: 60, engagementSalesperson: 9.0, engagementProspect: 9.0, sentimentSalesperson: 4.2, sentimentProspect: 3.0, topic: "Identifying PG RDS Pain" },
      { timestamp: "01:15", seconds: 75, engagementSalesperson: 8.5, engagementProspect: 8.0, sentimentSalesperson: 4.0, sentimentProspect: 3.5, topic: "Urgency Booking" },
      { timestamp: "01:30", seconds: 90, engagementSalesperson: 8.0, engagementProspect: 7.0, sentimentSalesperson: 4.0, sentimentProspect: 3.0, topic: "Call Closing" }
    ],
    coachingCard: {
      salespersonName: "Marcus Fenix",
      overallScore: 88,
      summary: "Superb execution of cold calling tactics in a high-friction environment. Marcus respected the prospect's hard limit, grabbed immediate focus via technical specificity, and successfully locked in a secondary appointment.",
      strengths: [
        { title: "Objection Pivot", description: "When the prospect declared they were walking into a meeting, Marcus did not panic. He pivoted gracefully, asking for just 10 seconds of permission.", tag: "Mindset" },
        { title: "High-Value Hook", description: "Using highly specific technical jargon ('zero read lockups' and '4-second backups') immediately activated the DevOps manager's problem awareness.", tag: "Hooking" },
        { title: "Clean Next Step Lock", description: "Instead of dragging the call out after landing the hook, he maintained professional boundaries and rapidly locked down Tuesday 10 AM, exiting on a high note.", tag: "Time Mastery" }
      ],
      missedOpportunities: [
        { title: "Rushed Intro Delivery", description: "Marcus's speech rate was slightly fast in the first 10 seconds, which can trigger an instant hangup defense reflex.", tag: "Voice Mod" },
        { title: "Assuming Single DM", description: "He didn't ask if any other team members are affected by the EU developer blockages, missing out on multi-threading the Tuesday meeting early.", tag: "Account Map" },
        { title: "Missing Contact Backup", description: "He accepted a generic group alias ('devops@') rather than securing the individual's direct corporate cell phone number as a backup.", tag: "Contact Info" }
      ],
      actionPlan: [
        "Slightly slow down the pacing of the 45-second script by 10-15% to increase authority.",
        "Add a multi-threading question: 'Should we loop in your database administrator to make our Tuesday workshop highly technical?'",
        "Prompt for a direct mobile contact is a key risk mitigator for cold call calendar appointments."
      ]
    }
  }
};

// Start Express setup
async function startServer() {
  const app = express();

  // Middleware for body parsing with limits up to 50MB to handle core base64 files
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // API endpoint: Get preset analytics instantly
  app.get("/api/preset/:id", (req, res) => {
    const id = req.params.id;
    if (DEMO_PRESETS[id]) {
      return res.json({ success: true, data: DEMO_PRESETS[id] });
    }
    return res.status(404).json({ success: false, error: "Demo preset not found." });
  });

  // API endpoint: Live Gemini transcript diarization and analysis
  app.post("/api/analyze", async (req, res) => {
    try {
      const { audioBase64, mimeType, fileName } = req.body;

      if (!audioBase64) {
        return res.status(400).json({
          success: false,
          error: "No audio stream provided. Please upload an audio file.",
        });
      }

      if (!ai) {
        // Return beautiful mock analysis as fallback if API key is not configured,
        // letting the user proceed seamlessly but warning them
        console.warn("GEMINI_API_KEY is not defined in the environment. Using smart simulation mode.");
        const fallbackId = fileName?.toLowerCase().includes("cold") ? "cold" : "saas";
        return res.json({
          success: true,
          isSimulated: true,
          data: DEMO_PRESETS[fallbackId],
          warning: "API Key omitted in Settings > Secrets. Viewing simulated coaching analysis.",
        });
      }

      // Prepare standard multimodal inline part for @google/genai
      const audioPart = {
        inlineData: {
          data: audioBase64,
          mimeType: mimeType || "audio/mp3",
        },
      };

      const systemInstruction = 
        "You are an elite Sales Performance & Coaching Analyst. " +
        "Analyze the uploaded sales call audio carefully. " +
        "1. Perform diarization: Identify Speaker A (the Representative) vs Speaker B (the Customer/Prospect). " +
        "Provide a high-fidelity chronological transcript marking timestamps (MM:SS) and conversational text. " +
        "2. Provide metric datapoints (every 10-20 seconds) for sentiment/engagement curves. " +
        "3. Grade the salesperson out of 100 on overall effectiveness, summarize the exchange, and list exactly 3 distinct strengths and 3 clear missed opportunities with actionable remediation steps.";

      const prompt = `Analyze this sales call audio: ${fileName || "uploaded_call.mp3"}. Provide output following the exact JSON Schema specified. Ensure that Speak A acts as the sales representative, and Speaker B is the prospect.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [audioPart, prompt],
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              transcript: {
                type: Type.ARRAY,
                description: "Array of chronological transcript dialogues matching the speakers in the call.",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    speaker: {
                      type: Type.STRING,
                      description: "Role of the speaker: either 'A' (Salesperson) or 'B' (Prospect)."
                    },
                    timestamp: {
                      type: Type.STRING,
                      description: "Format MM:SS representing offset time of conversation, e.g. '00:15'."
                    },
                    seconds: {
                      type: Type.INTEGER,
                      description: "Count of seconds since conversation initiation, e.g. 15."
                    },
                    text: {
                      type: Type.STRING,
                      description: "The transcribed narrative verbalized by the speaker."
                    }
                  },
                  required: ["speaker", "timestamp", "seconds", "text"]
                }
              },
              timelineMetrics: {
                type: Type.ARRAY,
                description: "Sequential metric points capturing interaction sentiment/engagement throughout the call timeline.",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    timestamp: {
                      type: Type.STRING,
                      description: "Corresponding timer flag, e.g. '00:15'."
                    },
                    seconds: {
                      type: Type.INTEGER,
                      description: "Continuous second counter, e.g. 15."
                    },
                    engagementSalesperson: {
                      type: Type.NUMBER,
                      description: "Dynamic tone pitch and flow energy rating for representative out of 10."
                    },
                    engagementProspect: {
                      type: Type.NUMBER,
                      description: "Dynamic responsive interest engagement rating for client out of 10."
                    },
                    sentimentSalesperson: {
                      type: Type.NUMBER,
                      description: "Positivity bias for representative. Rating scale from -5 (deep negative/hostile) to +5 (vibrant positive)."
                    },
                    sentimentProspect: {
                      type: Type.NUMBER,
                      description: "Positivity bias for prospect. Rating scale from -5 to +5."
                    },
                    topic: {
                      type: Type.STRING,
                      description: "Subject matter scope during this segment, e.g., 'Pricing Discussion', 'Greeting', 'Closing call'."
                    }
                  },
                  required: ["timestamp", "seconds", "engagementSalesperson", "engagementProspect", "sentimentSalesperson", "sentimentProspect", "topic"]
                }
              },
              coachingCard: {
                type: Type.OBJECT,
                description: "Expert constructive coaching scorecard.",
                properties: {
                  salespersonName: {
                    type: Type.STRING,
                    description: "Detected name of salesperson or defaults to 'Sales Representative'."
                  },
                  overallScore: {
                    type: Type.INTEGER,
                    description: "Coaching score grading out of 100 percentage points."
                  },
                  summary: {
                    type: Type.STRING,
                    description: "High performance objective descriptive overview of the interaction (2-3 sentences)."
                  },
                  strengths: {
                    type: Type.ARRAY,
                    description: "Absolutely exactly 3 key strengths displayed by the salesperson.",
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        title: { type: Type.STRING, description: "Descriptive label, e.g., 'Strategic Pausing'." },
                        description: { type: Type.STRING, description: "Specific reference detailing why this is a strong skill." },
                        tag: { type: Type.STRING, description: "One word category tag, e.g. 'Discovery', 'Closing', 'Overcoming Objection'." }
                      },
                      required: ["title", "description", "tag"]
                    }
                  },
                  missedOpportunities: {
                    type: Type.ARRAY,
                    description: "Absolutely exactly 3 clear corrective spots where improvement can trigger larger conversions.",
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        title: { type: Type.STRING, description: "Descriptive objection or area for improvement, e.g., 'Interrupted objection'." },
                        description: { type: Type.STRING, description: "Critical overview of what went wrong and how this missed quota opportunity." },
                        tag: { type: Type.STRING, description: "Area tag, e.g. 'Empathy', 'Price Frame', 'Active Listening'." }
                      },
                      required: ["title", "description", "tag"]
                    }
                  },
                  actionPlan: {
                    type: Type.ARRAY,
                    description: "A constructive, clean step-by-step 3-point remediation action plan for the representative to train on.",
                    items: {
                      type: Type.STRING
                    }
                  }
                },
                required: ["salespersonName", "overallScore", "summary", "strengths", "missedOpportunities", "actionPlan"]
              }
            },
            required: ["transcript", "timelineMetrics", "coachingCard"]
          }
        },
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("Empty response received from Gemini analysis cluster.");
      }

      const analyzedPayload = JSON.parse(responseText.trim());
      res.json({ success: true, data: analyzedPayload });
    } catch (err: any) {
      console.error("Gemini Multi-Modal Audio analysis crash: ", err);
      res.status(500).json({
        success: false,
        error: `Could not analyze audio: ${err.message || err}`,
      });
    }
  });

  // Serve static files in production or hook Vite in development
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Sales Coaching Intel Server online at http://0.0.0.0:${PORT}`);
  });
}

startServer();
